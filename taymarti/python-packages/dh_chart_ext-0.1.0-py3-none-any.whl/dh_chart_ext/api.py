"""
The chart API: charts on demand as shared nodes (nodes.ChartNodes), served to front ends that draw
their own charts. It is an rpc.Api with chart handlers; an app can add its own methods to it.

    chart_api = ChartApi(source)        # in the app script; publish it like a table (type acme.Api)

Methods (besides rpc's hello, describe, ping, release, whoami):

  chart    {sym, res, studies?}  -> {key, sym, res, columns: [{column, pane, study, levels?}], tick}  + the table
           one instrument's bars (Timestamp Open High Low Close Volume Updated) with the studies' columns;
           studies: ["EMA_20", {"type": "RSI", "params": {"length": 14}}, ...]; sym may be a spread ("ES-NQ")
  bars     {sym, res}            -> {key, sym, res, tick}  + the table
  symbols  {}                    -> [sym, ...]
  resolutions {}                 -> ["1s", "5s", ...]
  studies  {}                    -> the study types and their parameters
  stats    {}                    -> streams, this stream's holds, and every cached node

Each chart or bars request holds its node for the stream until `release {key}`, the stream closes, or
its lease runs out (rpc.Api). The node is shared with every other client asking for the same chart.
"""
from __future__ import annotations

from typing import Optional

from .data import STUDY_TYPES
from .instruments import tick_for
from .nodes import ChartNodes, resolution_name, resolution_options
from .rpc import Api, Context, Reply

RSI_LEVELS = [30.0, 70.0]


class ChartApi(Api):
    """The chart methods over a ChartSource's nodes."""

    def __init__(self, source, nodes: Optional[ChartNodes] = None, *, name: str = "chart_api", **kw):
        super().__init__(name, **kw)
        self.nodes = nodes or source.nodes
        nodes_ = self.nodes

        def hold(ctx: Context, key) -> bool:
            return ctx.hold(key, lambda: nodes_.release(key))

        @self.method(tables=True)
        def chart(ctx, sym: str, res: str, studies: list = []):  # noqa: B006 (never mutated)
            """One instrument's bars with the studies' columns, as a shared node."""
            objs = nodes_.canonical_studies(studies)
            key, table, _cols = nodes_.chart(sym, res, list(objs.values()))
            if not hold(ctx, key):
                return None
            columns = [{"column": c, "pane": s.pane, "study": k, **({"levels": RSI_LEVELS} if s.pane == "rsi" else {})}
                       for k, s in objs.items() for c in s.columns()]
            return Reply({"key": key, "sym": key[1], "res": resolution_name(key[2]), "columns": columns,
                          "tick": tick_for(key[1])}, tables=[table])

        @self.method(tables=True)
        def bars(ctx, sym: str, res: str):
            """One instrument's bars, as a shared node."""
            key, table = nodes_.bars(sym, res)
            if not hold(ctx, key):
                return None
            return Reply({"key": key, "sym": key[1], "res": resolution_name(key[2]), "tick": tick_for(key[1])}, tables=[table])

        @self.method
        def symbols(ctx):
            """The symbols seen so far."""
            return nodes_.symbols()

        @self.method
        def resolutions(ctx):
            """Resolutions a toolbar can offer (any other from 1s to 1d also works)."""
            return resolution_options()

        @self.method
        def studies(ctx):
            """The study types and their parameters' defaults."""
            return [{"type": k, "label": t.label, "group": t.group, "params": t.params} for k, t in STUDY_TYPES.items()]

        @self.method
        def stats(ctx):
            """Streams, this stream's holds, and every cached node."""
            return {"streams": self.streams, "held": ctx.holding(), "nodes": nodes_.cache.stats()}
