"""
dh_chart_ext: our chart features for Deephaven, server side.

Installing this package registers one JS plugin with the Deephaven server. It applies @acme/chart-ext
(ext/: our Lightweight Charts plugins) to every TradingView chart in any Deephaven web UI,
deephaven.ui dashboards included.

Python layers (see README.md for which front ends each one serves):
  dh_chart_ext.store      P   annotations (price lines, drawings) in one table for every front end
  dh_chart_ext.data       L0  tables: bars, studies, the published standard set
  dh_chart_ext.charts     L1  TvlCharts composed from L0 tables
  dh_chart_ext.workspace  L2  a deephaven.ui workspace: toolbar, 1-4 charts, legend, watchlist, alerts
  dh_chart_ext.alerts     P   alerts in one table, evaluated in the engine (AlertEngine)
  dh_chart_ext.sessions       trading-session calendars per instrument
  dh_chart_ext.cache          NodeCache: shared, reference-counted tables keyed by request
  dh_chart_ext.nodes          ChartNodes: chart tables on demand (bars, studies, spreads) as shared nodes
  dh_chart_ext.api            ChartApi: the chart API object type (acme.chart.Api) for JS clients

They import deephaven, so they load only inside a Deephaven worker; import them explicitly.
"""
